<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>HOME:: EDUCATION HUB</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
</head>
<body id="page1">
<div class="body1">
  <div class="main">
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
            <li class="end"><a href="chart.php">Chart</a></li>
            <?php if (!empty($_SESSION["NAME"])) {
              echo "<li><a>".$_SESSION["NAME"]."</a></li>";
              echo"<li><a href='logout.php'>Logout</a></li>";
              echo"<li><a href='admin.php'>Admin</a></li>";
            } ?>
          </ul>
        </nav>
      </div>
    </header>
        
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Statistics',''],
          ['No of Users', 5],
          ['No of java users', 2],
          ['No of c/c++ users', 3],
          ['No of python users', 5],
          ['No of web Deblopment users', 2],
          ['No of android users', 7],
        ]);

        var options = {
          chart: {
            title: 'EDUCATION HUB',
            subtitle: 'No of Users, No of courses',
          },
          bars: 'horizontal' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="barchart_material" style="width: 900px; height: 500px;"></div>
  

      <div class="wrapper">
        <h1><a href="index.php" id="logo">EDUCATION HUB</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
      <ul class="banners">
        <li><a href="#"><img src="images/banner1.jpg" alt=""></a></li>
        <li><a href="#"><img src="images/banner2.jpg" alt=""></a></li>
        <li><a href="#"><img src="images/banner3.jpg" alt=""></a></li>
      </ul>
    </header>
  </div>
</div>
</body>
</html>