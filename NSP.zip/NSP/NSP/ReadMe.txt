Author: CodexWorld
Author URL: http://www.how2doit.ga/
Author Email: hrwndr97@gmail.com

============ Introduction ============
This project helps web developers to implement the user registration with Google account using PHP at their website project. Also the user information would be stored at the MySQL database.

============ Installation ============
1. Create a database (codexworld) at phpMyAdmin and import the db_users.sql file into the database (codexworld).
2. Open the User.php file and modify the $dbHost, $dbUsername, $dbPassword, $dbName variables value with your MySQL database credentials.
3. Open the "gpConfig.php" file and  and specify the $appId, $appSecret, and $redirectURL as per your Google Project API credentials.
4. Browse the index.php file in the browser and test the Login with Facebook functionality.

============ May I Help You ===========
If you have any query about this script, send the query by E-Mailing here - hrwndr97@gmail.com
-----------------------------------
DONATE US: CONTRIBUTE TO GROW
-----------------------------------
Donate us from here - 
https://www.instamojo.com/@hrwndr