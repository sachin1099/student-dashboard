<?php
  session_start();
  include_once("src/Google_Client.php");
  include_once("src/contrib/Google_Oauth2Service.php");
  // Fill CLIENT ID, REDIRECT URI from Google Developer Console
  $client_id = '91548785375-jlka7k82o6nt6nvqlbcbfnk57tjnsp9d.apps.googleusercontent.com';
  $client_secret = 'lQhffuvUrqcxgQWbnjQSVcb6';
  $redirect_uri = 'http://bitsandbytes2018.000webhostapp.com';

  //Create Client Request to access Google API
  $client = new Google_Client();
  $client->setClientID($client_id);
  $client->setClientSecret($client_secret);
  $client->setRedirectUri($redirect_uri);
  //$client->addScope("https://www.googleapis.com/auth/userinfo.email");

  //Send Client Request
  $objOAuthService = new Google_Oauth2Service($client);
  ?>