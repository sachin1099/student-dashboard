<?php 
//Include GP config file && User class
include_once 'gpConfig.php';
include_once 'User.php';

  
    //Authenticate code from Google OAuth Flow
  //Add Access Token To Session
  if (isset($_GET['code'])) {
    $client->authenticate($_GET['code']);
    $_SESSION['access_token'] = $client->getAccessToken();
    header('Location: '. filter_var($redirect_uri, FILTER_SANITIZE_URL));  
  }

  //Set Access Token to make Request
  if (isset($_SESSION['access_token'])&& $_SESSION['access_token']) {
    $client->setAccessToken($_SESSION['access_token']);
  }

  //Get User Data from Google Plus
  if ($client->getAccessToken()) {
    $gpUserProfile = $objOAuthService->userinfo->get();
    $_SESSION['access_token'] = $client->getAccessToken();
    //Initialize User class
  $user = new User();
  
  //Insert or update user data to the database
    $gpUserData = array(
        'oauth_provider'=> 'google',
        'oauth_uid'     => $gpUserProfile['id'],
        'first_name'    => $gpUserProfile['given_name'],
        'last_name'     => $gpUserProfile['family_name'],
        'email'         => $gpUserProfile['email'],
        'gender'        => $gpUserProfile['gender'],
        'locale'        => $gpUserProfile['locale'],
        'picture'       => $gpUserProfile['picture'],
        'link'          => $gpUserProfile['link']
    );
    $userData = $user->checkUser($gpUserData);
  
  //Storing user data into session
  $_SESSION['userData'] = $userData;
  
  //Render facebook profile data
    if(!empty($userData)){
        $output = '<h1>Google+ Profile Details </h1>';
        $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
        $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
        $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
        $output .= '<br/>Email : ' . $userData['email'];
        $output .= '<br/>Gender : ' . $userData['gender'];
        $output .= '<br/>Locale : ' . $userData['locale'];
        $output .= '<br/>Logged in with : Google';
        $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
        $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
    }
} else {
  $authUrl = $client->createAuthUrl();
  $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/></a>';
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>	</title>
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script type="js/jquery.min.js"></script>
<script type="js/bootstrap.min.js"></script>

</head>
<body>

	<nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
          </ul></nav><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 	<form method="post">
        <center> <div class="panel panel-primary" style="width: 40%">
         <div class="panel-heading">USER LOGIN</div>
           <div class="panel-body">
          
           <span style="float:left; font-size: 18px;">E-MAIL:</span>
           	<input type="email" name="email" class="form-control">
              <span style="float:left; font-size: 18px;"> PASSWORD:</span>
           	<input type="password" class="form-control" name="pwd">
           	<br>
           	<br>
           	<a href="forget.php">forgot password?</a>
           </div>
           <div class="panel-footer">
            <input type="submit" class="btn btn-success" name="sub" value="Submit">
            <input type="reset" class="btn btn-danger" value="Reset">
               <div><?php echo $output; ?></div>
           </div>
       </form>
         </div></center>
         <?php
         if (isset($_POST['sub'])) {
         	echo "ssgs";
                          
                                 $a=$_POST['email'];
                                $b=$_POST['pwd'];
                             $conn=mysqli_connect("localhost","root","","education");
                    		  $sql="select * FROM user WHERE email='$a' && password='$b'";
                    		   	$result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result)){
                                    session_start();
                                    $row=mysqli_fetch_assoc($result);
								    $_SESSION["NAME"]=$row['name'];$_SESSION["EMAIL"]=$row['email'];
								    $_SESSION["MNO"]=$row['mob'];$_SESSION["COURSE"]=$row['course'];
                                    $_SESSION["TYPE"]=$row['type'];echo "<script>window.location.assign('index.php');</script>";
                    		   }
                                else
                                {
                            ?>
                            <script>
                                alert("wrong inputs")
                                </script>
                            <?php
                                }
                    		}
                    	 ?>
</body>
</html>