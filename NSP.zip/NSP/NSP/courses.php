<!DOCTYPE html>
<html lang="en">
<head>
<title>EDUCATION HUB | Courses</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
</head>
<body id="page2">
<div class="body1">
  <div class="main">
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
          </ul>
        </nav>
      </div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">EDUCATION HUB</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
    </header>
  </div>
</div>
<div class="body2">
  <div class="main">
    <section id="content">
      <div class="box1">
        <div class="wrapper">
          <article class="col1">
            <div class="pad_left1">
              <h2 class="pad_bot1">Basic Courses</h2>
            </div>
            <div class="wrapper pad_bot1">
              <figure class="left marg_right1"><img src="images/page2_img1.jpg" alt=""></figure>
              <p class="pad_bot1 pad_top2"><strong>JAVA- BASIC AND CORE, .NET, C#, C , C++, WEB DEVELOPEMNET, ANDROID, SWIFT, PYTHON, R-LANGUAGE, </strong></p>
              <p>THESE COURSES ARE AVAILABLE FOR ALL THE STUDENTS WHO ARE  INTRESTED IN THE DEVELOPMENT OF THE SKILLS IN THE FIELDS OF HUGE TECHNOLOGY </p>
            </div>
            <div class="pad_left1">
              <div class="box2">
                <div class="wrapper">
                  <div class="cols">
                    <ul class="list3">
                      <li><a href="#">JAVA-BASICS AND CORE</a></li>
                      <li><a href="#">.NET</a></li>
                      <li><a href="#">C#</a></li>
                      <li><a href="#">C AND C++</a></li>
                    </ul>
                  </div>
                  <div class="cols pad_left2">
                    <ul class="list3">
                      <li><a href="#">WEB DEVELOPMENT</a></li>
                      <li><a href="#">ANDROID</a></li>
                      <li><a href="#">SWIFT</a></li>
                      <li><a href="#">PYTHONS</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <p><strong>JOIN US FOR ONLINE COUSES</strong> ALL THE STUDENTS GET CERTIFIED COURSE FROM THE EDUCATION HUB FOR THE COURSE ALL ARE ALSO GET SOME SUCCESFUL TRAINING EXPIRIENCES FROM THE INDUSTRIES</p>
            </div>
            <a href="#" class="button"><span><span>Read More</span></span></a> </article>
          <article class="col2 pad_left2">
            <div class="pad_left1">
              <h2>Special Courses</h2>
            </div>
            <ul class="list1 pad_bot1">
              <li><a href="#">SAP</a></li>
              <li><a href="#">LINGUISTICS COURSES</a></li>
              <li><a href="#">PERSONALITY DEVELOPMENT</a></li>
              <li><a href="#">PROFESSIONAL ETHICS</a></li>
            </ul>
            <a href="#" class="button"><span><span>Read More</span></span></a>
            <div class="pad_left1">
              <h2 class="marg_top1">Evening Courses</h2>
              <p><strong>THE FOLLOWING MENTION COURSES ARE LIVE FROM THE EVENING</strong><br>
               JAVA- BASIC AND CORE, .NET, C#, C , C++, WEB DEVELOPEMNET, ANDROID<br>
                THESE ARE THE COURSES AVAILABLE IN WHICH ARE AVAILABLE IN EVENING AS WELL</p>
            </div>
            <a href="#" class="button"><span><span>Read More</span></span></a> </article>
        </div>
      </div>
    </section>
    <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_1">
                <h3>Address:</h3>
                <p class="col_address"><strong>Country:<br>
                  City:<br>
                  Address:<br>
                  Email:</strong></p>
                  <p>INDIA<br>
                  JAIPUR<br>
                  PIET,CAMPUS<br>
                  <a href="#">educationhub@gmail.com</a></p>
              </article>
              <article class="col_2 pad_left2">
                <h3>Join In:</h3>
                <ul class="list2">
                  <li><Sli><a href="#">Sign Up</a></li>
                  <li><a href="#">Login</a></li>
                </ul>
              </article>
              <article class="col_3 pad_left2">
                <h3>Why Us:</h3>
                <ul class="list2">
                  <li><a href="#">FOR A BRIGHT FUTURE </a></li>
                  <li><a href="#">ENHANCMENT OF YOUR SOFT SKILLS</a></li>
                  <li><a href="#">INCRIDIBLE ENVIRONMENT FOR EDUCATION</a></li>
                  <li><a href="#">QUALITY EDUCATION</a></li>
                </ul>
              </article>
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Call Us Now: </span><span class="call2">8094682702</span> </article>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
</body>
</html>