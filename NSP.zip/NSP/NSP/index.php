<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>HOME:: EDUCATION HUB</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
</head>
<body id="page1">
<div class="body1">
  <div class="main">
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
            <?php if (!empty($_SESSION["NAME"])) {
              echo "<li><a>".$_SESSION["NAME"]."</a></li>";
              echo"<li><a href='logout.php'>Logout</a></li>";
              echo"<li><a href='admin.php'>Admin</a></li>";
            } ?>
          </ul>
        </nav>
      </div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">EDUCATION HUB</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
      <ul class="banners">
        <li><a href="#"><img src="images/banner1.jpg" alt=""></a></li>
        <li><a href="#"><img src="images/banner2.jpg" alt=""></a></li>
        <li><a href="#"><img src="images/banner3.jpg" alt=""></a></li>
      </ul>
    </header>
  </div>
</div>
<div class="body2">
  <div class="main">
    <section id="content">
      <div class="wrapper">
        <div class="pad1 pad_top1">
          <article class="cols marg_right1">
            <figure><a href="#"><img src="images/page1_img1.jpg" alt=""></a></figure>
            <span class="font1">Our Mission Statement</span> </article>
          <article class="cols marg_right1">
            <figure><a href="#"><img src="images/page1_img2.jpg" alt=""></a></figure>
            <span class="font1">Performance Report</span> </article>
          <article class="cols">
            <figure><a href="#"><img src="images/page1_img3.jpg" alt=""></a></figure>
            <span class="font1">Prospective Parents</span> </article>
        </div>
      </div>
      <div class="box1">
        <div class="wrapper">
          <article class="col1">
            <div class="pad_left1">
              <h2>Welcome to Our Portal</h2>
            </div>
            <div class="pad_left1">
              <h2>Individual Approach to Education!</h2>
            </div>
            <div class="wrapper">
              <figure class="left marg_right1"><img src="images/page1_img4.jpg" alt=""></figure>
              <p class="pad_bot1 pad_top2"><strong>ONE TO ONE CONTACT IN FACULTIES AND THE STUDENTS</strong></p>
              <p> Learn Center PROVIDES YOU THE BETTER LEARNING CHANCE TO INTERACT WITH THE INTELECTUAL THROUGH THE ONLINE MEDIUM PROVIDING INTERESTED COURSES TO MOTIVATE  INDIVIDUAL INTO A SPECIFIC PATH.</p>
            </div>
            <div class="pad_top2"> <a href="#" class="button"><span><span>Read More</span></span></a> </div>
          </article>
          <article class="col2 pad_left2">
            <div class="pad_left1">
              <h2>New Programs</h2>
            </div>
            <ul class="list1">
              <li><a href="#">International Studies</a></li>
              <li><a href="#">Language Reaching</a></li>
              <li><a href="#">Technical Proficiency</a></li>
              <li><a href="#">Professional Studies</a></li>
              <li><a href="#">Education Jobs</a></li>
            </ul>
            <div class="pad_left1">
              <h2>Latest News</h2>
            </div>
            <div class="wrapper"> <span class="date">2</span>
              <p class="pad_top2"><a href="#">November,2018</a><br>
                REGISTRATION LINK OPEN FOR THE NEW BATCH.</p>
            </div>
            <div class="wrapper"> <span class="date">12</span>
              <p class="pad_top2"><a href="#">November, 2018</a><br>
                COMENCEMENT OF REGULAR CLASSES.</p>
            </div>
            <div class="pad_top2"> <a href="#" class="button"><span><span>Read More</span></span></a> </div>
          </article>
        </div>
      </div>
    </section>
    <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_1">
                <h3>Address:</h3>
                <p class="col_address"><strong>Country:<br>
                  City:<br>
                  Address:<br>
                  Email:</strong></p>
                <p>INDIA<br>
                  JAIPUR<br>
                  PIET,CAMPUS<br>
                  <a href="#">educationhub@gmail.com</a></p>
              </article>
              <article class="col_2 pad_left2">
                <h3>Join In:</h3>
                <ul class="list2">
                  <li><a href="signup.php">Sign Up</a></li>
                  <li><a href="login.php">Login</a></li>
                </ul>
              </article>
              <article class="col_3 pad_left2">
                <h3>Why Us:</h3>
                <ul class="list2">
                  <li><a href="#">FOR A BRIGHT FUTURE </a></li>
                  <li><a href="#">ENHANCMENT OF YOUR SOFT SKILLS</a></li>
                  <li><a href="#">INCRIDIBLE ENVIRONMENT FOR EDUCATION</a></li>
                  <li><a href="#">QUALITY EDUCATION</a></li>
                </ul>
              </article>
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Call Us Now: </span><span class="call2">8094682702</span> </article>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>

<script type="text/javascript">Cufon.now();</script>
</body>
</html>