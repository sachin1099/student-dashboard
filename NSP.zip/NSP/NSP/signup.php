<?php 
session_start();
if (!empty($_SESSION["NAME"])) {
  header('location:index.php');
}
  else
  {
?>
<html>
<head>
	<title>signup</title>
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script type="js/jquery.min.js"></script>
<script type="js/bootstrap.min.js"></script>

<script type="text/javascript">
  function check() {
      var a=document.getElementById('p1').value;
      var b=document.getElementById('p2').value;

      if (a!=b) {
        alert('Password not matched');
      }
  }
  </script>

</head>
<body>
	<nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
          </ul><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>


          
        <center>  <div class="panel panel-primary" style="width: 60%">
            <div class="panel-heading">
                    signup
                </div>
                <div class="body">
                <form action="mail/umail.php" method="post" onsubmit=" return check() ">
                                NAME:
                          <input type="text" class="form-control" id="t1" name="uname" placeholder="enter your name" required>
                                    EMAIL ID:
                         <input type="email" class="form-control" name="uemail" placeholder="enter your em" required>
                                    MOB. NO.:
                          <input type="text" class="form-control" name="umob" placeholder="enter your mob. no." maxlength="10" minlength="10" required>
                                             DOB:
                         <input type="date" class="form-control" name="uop" placeholder="enter your DOB" required>
                         SELECT YOUR COURSE:
                         <select class="form-control" name="usel"  required>
                                  <option>C/C++ </option>
                                   <option> JAVA </option>
                                    <option> PYTHON </option>
                                     <option> WEB DEVELOPEMENT </option>
                                     <option> ANDROID </option>


                          </select>
                          PASSWORD:
                          <input type="password" class="form-control" name="upass" id="P1" placeholder="enter your password" required>
                          CONFIRM-PASSWORD:
                          <input type="password" class="form-control" name="upass" id="P2" placeholder="enter your re-password" required><br><br>
                          <div class="panel-footer">
                          <input type="submit" class="btn btn-success" value="Submit">
                          <input type="reset" class="btn btn-danger" value="Reset">
                        </div>
                               </form>
                                     

                              </div>

                          </div></center>
                          <?php   }
?>


      <footer style="background-color: lightgray">
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_1">
                <h3>Address:</h3>
                <p class="col_address"><strong>Country:<br>
                  City:<br>
                  Address:<br>
                  Email:</strong></p>
                <p>INDIA<br>
                  JAIPUR<br>
                  PIET,CAMPUS<br>
                  <a href="#">educationhub@gmail.com</a></p>
              </article>
              <article class="col_2 pad_left2">
                <h3>Join In:</h3>
                <ul class="list2">
                  
                  <li><a href="login.php">Login</a></li>
                </ul>
              </article>
              <article class="col_3 pad_left2">
                <h3>Why Us:</h3>
                <ul class="list2">
                  <li><a href="#">FOR A BRIGHT FUTURE </a></li>
                  <li><a href="#">ENHANCMENT OF YOUR SOFT SKILLS</a></li>
                  <li><a href="#">INCRIDIBLE ENVIRONMENT FOR EDUCATION</a></li>
                  <li><a href="#">QUALITY EDUCATION</a></li>
                </ul>
              </article>
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Call Us Now: </span><span class="call2">8094682702</span> </article>
            </div>
          </div>
        </div>
      </div>
    </footer>

</body>
</html>