<!DOCTYPE html>
<html lang="en">
<head>
<title>EDUCATION HUB| ADMISSION</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
</head>
<body id="page5">
<div class="body1">
  <div class="main">
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
          </ul>
        </nav>
      </div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">EDUCATION HUB</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
    </header>
  </div>
</div>
<div class="body2">
  <div class="main">
    <section id="content">
      <div class="box1">
        <div class="wrapper">
          <article class="col1">
            <div class="pad_left1">
              <h2 class="pad_bot1">Our Mission</h2>
              <p class="pad_bot1 pad_top2"><strong>EDUCATION HUB's  MISSION IS TO PROMOTE STUDENT ACHIEVEMENT AND PREPARATION FOR GLOBAL COMPETATIVENESS BY FOSTORING EDUCATIONAL  EXCELLENCE AND ENSURING EQUAL ACCESS.</strong></p>
             BE A PROFICIENTLY ACCLAIMED INSTITUTION RECOGNIZED FOR EXCELLENCE IN TEACHING, RESEARCH AND OUTREACH PROVIDE THE HIGHEST QUALITY OF EDUCATION TO STUDENT TO NURTURE THEIR TALENT, PROMOTE INTELLECTUAL GROWTH AND SHAPE THEIR PERSONAL DEVELOPMENT.</div>
            <div class="pad_left1">
              <h2 class="pad_bot1">Terms of Admission</h2>
            </div>
            <div class="wrapper">
              <figure class="left marg_right1"><img src="images/page5_img1.jpg" alt=""></figure>
              <p class="pad_top2"><strong>A DEDICATED STUDENT WITH ENTHUSIASM FOE LEARNING</strong> SKILLS TO PROMOTE THE IDEAOLOGY OF SCIENCE AND TECHNOLOGY. GOOD WITH SPEAKING SKILLS. DEDICATED TOWARD THE GOALS.</p>
            </div>
            <div class="wrapper pad_top2">
              <div class="pad_left1">
                <div class="box2">
                  <div class="wrapper">
                    <div class="cols">
                      <ul class="list3">
                        <li><a href="#">TRAINING</a></li>
                        <li><a href="#">INTERNSHIPS</a></li>
                        <li><a href="#">WORKSHOPS</a></li>
                      </ul>
                    </div>
                    <div class="cols pad_left2">
                      <ul class="list3">
                        <li><a href="#">CONFERENCES</a></li>
                        <li><a href="#">CONVOCATIONS</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <a href="#" class="button marg_top1"><span><span>Read More</span></span></a> </article>
          <article class="col2 pad_left2">
            <div class="pad_left1">
              <h2>Important Dates</h2>
            </div>
            <div class="wrapper"> <span class="date">16</span>
              <p class="pad_top2"><a href="#">November, 2018</a><br>
                Registered Student's List Released</p>
            </div>
            <div class="wrapper"> <span class="date">19</span>
              <p class="pad_top2"><a href="#">November, 2018</a><br>
                Online Entrance Exam</p>
            </div>
            <div class="wrapper"> <span class="date">23</span>
              <p class="pad_top2"><a href="#">November, 2018</a><br>
                Result Declare for The Online Exam</p>
            </div>
            <div class="wrapper"> <span class="date">24</span>
              <p class="pad_top2"><a href="#">November, 2018</a><br>
                Interview of the shorlisted students</p>
            </div>
            <div class="wrapper pad_bot2"> <span class="date">26</span>
              <p class="pad_top2"><a href="#">November, 2011</a><br>
                First Introduction Session</p>
            </div>
            <a href="#" class="button"><span><span>Read More</span></span></a> </article>
        </div>
      </div>
    </section>
    <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_1">
                <h3>Address:</h3>
                <p class="col_address"><strong>Country:<br>
                  City:<br>
                  Address:<br>
                  Email:</strong></p>
                <p>INDIA<br>
                  JAIPUR<br>
                  PIET,CAMPUS<br>
                  <a href="#">educationhub@gmail.com</a></p>
              </article>
              <article class="col_2 pad_left2">
                <h3>Join In:</h3>
                <ul class="list2">
                  <li><a href="#">Sign Up</a></li>
                  <li><a href="#">Login</a></li>
                </ul>
              </article>
              <article class="col_3 pad_left2">
                <h3>Why Us:</h3>
                <ul class="list2">
                  <li><a href="#">FOR A BRIGHT FUTURE </a></li>
                  <li><a href="#">ENHANCMENT OF YOUR SOFT SKILLS</a></li>
                  <li><a href="#">INCRIDIBLE ENVIRONMENT FOR EDUCATION</a></li>
                  <li><a href="#">QUALITY EDUCATION</a></li>
                </ul>
              </article>
              
            <div class="wrapper">
              <article class="call"> <span class="call1">Call Us Now: </span><span class="call2">8094682702</span> </article>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
</body>
</html>