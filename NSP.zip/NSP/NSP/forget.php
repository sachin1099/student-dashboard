<?php 
                 	if (isset($_POST['submit'])) {
                    $a=$_POST['email'];
  $conn=mysqli_connect("localhost","root","","education");
  $sql="select * from user where email='$a'";
  $result=mysqli_query($conn,$sql);
  if (mysqli_num_rows($result)) {
    $row=mysqli_fetch_assoc($result);
    $mobile=$row["mob"];
    $message="Hi ".$row["name"]." your password "."is ".$row["password"];
    $json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=8094682702&Password=8094682702&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=sachiETvm93fhbRxorBYsaptDK"),true);
    if ($json["status"]==="success") {
       echo $json["msg"];
        
    }else{
       echo $json["msg"];
    }
 
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title> </title>
  <link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script type="js/jquery.min.js"></script>
<script type="js/bootstrap.min.js"></script>

</head>
<body>

  <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
          </ul></nav><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<div class="container" style="width:300px;">
  <form method="post">
       <center><div class="panel panel-primary" id="fp">
                  <div class="panel-heading">Forgot Password</div>
                  <div class="panel-body form-group">
                    <form method="post">
                      <input type="email" name="email" class="form-control"><br>
                      <input type="submit" name="submit" value="submit" class="btn btn-success form-control">

                    </form>
                

                       </div></div>
                  </div></form></div>
       </center>
        <br>
  </body>
  </html>