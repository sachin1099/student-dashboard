<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>HOME:: EDUCATION HUB</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
</head>
<body id="page1">
<div class="body1">
  <div class="main">
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
            <li class="end"><a href="chart.php">Chart</a></li>
            <?php if (!empty($_SESSION["NAME"])) {
              echo "<li><a>".$_SESSION["NAME"]."</a></li>";
              echo"<li><a href='logout.php'>Logout</a></li>";
              echo"<li><a href='admin.php'>Admin</a></li>";
            } ?>
          </ul>
        </nav>
      </div>
    </header>
      <div class="container">
  <div class="row well">
      <?php 
$servername="localhost";
$username="root";
$password="";
$dbname="education";

$conn=mysqli_connect($servername,$username,$password,$dbname);

  $sql="select * FROM user";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)>0)
  { $i=1;
    ?>
      <table border="2" style="width: 100%">
        <tr>
          <th colspan="5"><center><b>Users</b></center></th>
        </tr>
        <tr>
          <th><b>S. No.</b></th>
          <th><b>Name</b></th>
          <th><b>Email</b></th>
          <th><b>Mobile NO.</b></th>
          <th><b>Course</b></th>
        </tr>
    <?php while($row=mysqli_fetch_assoc($result)) {
        ?>
        <tr>
          <th><?php echo $i; ?></th>
          <th><?php echo $row["name"]; ?></th>
          <th><?php echo $row["email"]; ?></th>
          <th><?php echo $row["mob"]; ?></th>
          <th><?php echo $row["course"]; ?></th>
        </tr>
    <?php
    $i++;}
  } ?>
</table>
  </div>
</div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">EDUCATION HUB</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
      <ul class="banners">
        <li><a href="#"><img src="images/banner1.jpg" alt=""></a></li>
        <li><a href="#"><img src="images/banner2.jpg" alt=""></a></li>
        <li><a href="#"><img src="images/banner3.jpg" alt=""></a></li>
      </ul>
    </header>
  </div>
</div>