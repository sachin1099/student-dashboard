<!DOCTYPE html>
<html lang="en">
<head>
<title>EDUCATION HUB | Programs</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-replace.js"></script>
<script type="text/javascript" src="js/Molengo_400.font.js"></script>
<script type="text/javascript" src="js/Expletus_Sans_400.font.js"></script>
</head>
<body id="page3">
<div class="body1">
  <div class="main">
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
            <li><a href="index.php">About</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="programs.php">Programs</a></li>
            <li><a href="admission.php">Admissions</a></li>
            <li class="end"><a href="contacts.php">Contacts</a></li>
          </ul>
        </nav>
      </div>
      <div class="wrapper">
        <h1><a href="index.php" id="logo">EDUCATION HUB</a></h1>
      </div>
      <div id="slogan"> We Will Open The World<span>of knowledge for you!</span> </div>
    </header>
  </div>
</div>
<div class="body2">
  <div class="main">
    <section id="content">
      <div class="box1">
        <div class="wrapper">
          <article class="col1">
            <div class="pad_left1">
              <h2 class="pad_bot1">Online Programs</h2>
            </div>
            <div class="wrapper pad_bot2">
              <figure class="left marg_right1"><img src="images/page3_img1.jpg" alt=""></figure>
              <p class="pad_bot1 pad_top2"><strong>Professional Courses</strong> <br>
                EDUCATION HUB PROVIDES YOU THE PROFESSIONAL COURSES WHICH ARE USEFUL FOR THE FUTURE AND ALSO MAKES YOU ELIGIBLE TO GET YOUR DREAM JOBS</p>
              <a href="#" class="button marg_left1"><span><span>Read More</span></span></a> </div>
            <div class="wrapper pad_bot2">
              <figure class="left marg_right1"><img src="images/page3_img2.jpg" alt=""></figure>
              <p class="pad_bot1 pad_top2"><strong>Language Courses</strong> <br>
                EDUCATION HUB ALSO WORKS IN THE FIELD OF WORLD WIDE USE LANGUAGES TO PROVIDE YOU A EASY AND QUICK PLATFORM TO ADOPT THE CHANGES IN THE JOB PROFILES</p>
              <a href="#" class="button marg_left1"><span><span>Read More</span></span></a> </div>
            <div class="wrapper">
              <figure class="left marg_right1"><img src="images/page3_img3.jpg" alt=""></figure>
              <p class="pad_bot1 pad_top2"><strong>Technical Courses</strong> <br>
               THE MAIN OBJECTIVE OF EDUCATION HUB TO MAKE PEOPLE AWARE OF THE NEW TECHNOLOGY. THE STUDENTS WHO ARE INTRESTED IN THE FIELD OF TECHNOLOGY ARE MOST WELCOME TO JOIN  US TO BUILD AN ERA OF SCIENCE AND TECHNOLOGY </p>
              <a href="#" class="button marg_left1"><span><span>Read More</span></span></a> </div>
          </article>
          <article class="col2 pad_left2">
            <div class="pad_left1">
              <h2>New Programs</h2>
            </div>
            <ul class="list1">
              <li><a href="#">International Studies</a></li>
              <li><a href="#">Language Reaching</a></li>
              <li><a href="#">Technical Proficiency</a></li>
              <li><a href="#">Professional Studies</a></li>
              <li><a href="#">Education Jobs</a></li>
            </ul>
      </div>
    </section>
    <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_1">
                <h3>Address:</h3>
                <p class="col_address"> <strong> Country:<br>
                  City:<br>
                  Address:<br>
                  Email: </strong> </p>
                 <p>INDIA<br>
                  JAIPUR<br>
                  PIET,CAMPUS<br>
                  <a href="#">educationhub@gmail.com</a></p>
              </article>
              <article class="col_2 pad_left2">
                <h3>Join In:</h3>
                <ul class="list2">
                  <li><a href="#">Sign Up</a></li>
                  <li><a href="#">Login</a></li>
                </ul>
              </article>
              <article class="col_3 pad_left2">
                <h3>Why Us:</h3>
                <ul class="list2">
                  <li><a href="#">FOR A BRIGHT FUTURE </a></li>
                  <li><a href="#">ENHANCMENT OF YOUR SOFT SKILLS</a></li>
                  <li><a href="#">INCRIDIBLE ENVIRONMENT FOR EDUCATION</a></li>
                  <li><a href="#">QUALITY EDUCATION</a></li>
                </ul>
              </article>
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Call Us Now: </span><span class="call2">8094682702</span> </article>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
</body>
</html>