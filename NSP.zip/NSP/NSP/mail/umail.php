<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php
$p=$_POST["uname"];
$q=$_POST["uemail"];

// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'sachinrox2011@gmail.com';                 // SMTP username
    $mail->Password = '8094682702';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('welcom@gmail.com', 'education hub');
    $mail->addAddress($q,$p);     // Add a recipient
   // $mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo('no-reply@educationhub.com', 'No-Reply');
   // $mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Welcome to education hub';
    $mail->Body    = 'Hi,'.$p.'welcome to educationhub.Get ready to Dive In the Ocean Of Knowledge. Always updated with us<br>-Team educationhub';
    $mail->AltBody ='Hi,'.$p.'welcome to educationhub.Get ready to Dive In the Ocean Of Knowledge. Always updated with us-Team education hub';

    $mail->send();
    {   
$a=$_POST['uname'];
$b=$_POST['uemail'];
$c=$_POST['umob'];
$d=$_POST['uop'];
$e=$_POST['usel'];
$f=$_POST['upass'];
$conn=mysqli_connect("localhost","root","","education");
                if ($conn) 
                {
                    $sql="INSERT INTO `user`( `name`, `email`, `mob`, `dob`, `course`, `password`) VALUES ('$a','$b','$c','$d','$e','$f')";
                    if (mysqli_query($conn,$sql)) 
                    {                 
                                    $_SESSION["NAME"]=$a; $_SESSION["PASS"]=$f;
                                    $_SESSION["EMAIL"]=$b;
                                    $_SESSION["MOB"]=$c;
                                    $_SESSION["DOB"]=$d;
                                    $_SESSION["COURSE"]=$e;
                        }
                    }
    echo '<script>window.location.assign("../index.php");</script>';}
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}