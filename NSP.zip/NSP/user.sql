-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2018 at 04:28 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `education`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` varchar(10) NOT NULL,
  `dob` int(10) NOT NULL,
  `course` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `mob`, `dob`, `course`, `password`) VALUES
('sachin saurabh', '2017pietcsritik087@poornima.org', '8949782691', 2018, 'JAVA', '12345'),
('                    ', 'asd@ad.fsdgh', '5646546546', 2018, 'C/C++', ''),
('ritik', 'dgdgf@fffd.com', '4565465464', 665, 'JAVA', '53453456463544'),
('        ', 'dthtsuyhry@SFGFDS.SFGRSD', 'FGHLDSFUYH', 2021, 'PYTHON', '66641567'),
('          ', 'f@g.y', '1234567891', 1999, 'PYTHON', '12345'),
('          ', 'fhfdhr@sdfg.sg', '6578564697', 2018, 'C/C++', '6547564654'),
('      ', 'fsgs@sfgsr.sdfgwsrgf', '45764645yt', 2018, 'PYTHON', '455364545'),
('dhgdsh', 'goyalnimish2864@gmail.com', '1234135463', 2018, 'C/C++', '56415264'),
('ritik', 'hritikagarwal316@gmail.com', '8949782691', 2018, 'JAVA', '654321'),
('         ', 'jgfj@hvgjh.xfgfd', '1654515646', 564, 'C/C++', '654654654'),
('sachin saurabh', 'sachinrox2011@gmail.com', '8094682702', 1999, 'PYTHON', 'sachin1099'),
('         ', 'sfjghsj@asfd.af', '4556465415', 2009, 'C/C++', '65496854654'),
('SADFQW', 'SGFSG@ADFAF.ADF', 'SAGFSGFSGF', 6654, 'JAVA', '5646546'),
('suraj kumar', 'surajprasad841231@gmail.com', '9955947106', 2018, 'C/C++', '12345'),
('gjhgjg', 'yghjufg@gmail.com', '2635465656', 2018, 'WEB DEVELO', 'rtretertert');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
